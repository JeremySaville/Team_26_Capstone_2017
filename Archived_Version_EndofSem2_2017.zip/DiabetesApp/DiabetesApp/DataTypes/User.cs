﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DiabetesApp.DataTypes{
    public class User{
        public int gamified { get; set; }
        public string username { get; set; }
        public string dob { get; set; }
        public string phone { get; set; }
        public string HBA1C { get; set; }
    }
}
