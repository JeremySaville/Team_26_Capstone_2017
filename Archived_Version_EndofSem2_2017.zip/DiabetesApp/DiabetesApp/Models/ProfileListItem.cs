﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DiabetesApp.Models {
    class ProfileListItem {
        public string name { get; set; }
        public string id { get; set; }
        public string details { get; set; }
        public string imageLink { get; set; }
    }
}
