# Team_26_Capstone_2017
QUT Diabetes App development for IFB398/399


For assistance using the SourceTree Git Client please see: https://confluence.atlassian.com/get-started-with-sourcetree/get-started-with-sourcetree-847359026.html
